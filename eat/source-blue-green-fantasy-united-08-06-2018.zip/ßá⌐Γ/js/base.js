jQuery(window).load(function() {

    var docemsize = jQuery(window).height()*.03;

    jQuery('.allblock').css({"font-size":  docemsize+"px"});
    jQuery('.container').css({"padding-top":jQuery(window).height()*.1});
    
});